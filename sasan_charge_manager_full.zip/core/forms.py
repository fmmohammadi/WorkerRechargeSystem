from django import forms
from .models import ChargeTransaction, Worker

class ChargeTransactionForm(forms.ModelForm):
    class Meta:
        model = ChargeTransaction
        fields = ['worker', 'amount']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['amount'].widget.attrs.update({'placeholder': 'مثلاً 50000'})
        self.fields['worker'].queryset = Worker.objects.all()
