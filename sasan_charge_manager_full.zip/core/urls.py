from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.charge_create_view, name='charge_create'),
    path('list/', views.charge_list_view, name='charge_list'),
]
