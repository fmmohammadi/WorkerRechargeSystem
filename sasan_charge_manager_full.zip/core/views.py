from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import ChargeTransaction
from .forms import ChargeTransactionForm

@login_required
def charge_create_view(request):
    if request.method == 'POST':
        form = ChargeTransactionForm(request.POST)
        if form.is_valid():
            charge = form.save(commit=False)
            charge.buyer = request.user
            charge.save()
            return redirect(charge.get_charge_url())
    else:
        form = ChargeTransactionForm()
    return render(request, 'charge_create.html', {'form': form})

@login_required
def charge_list_view(request):
    transactions = ChargeTransaction.objects.all()
    return render(request, 'charge_list.html', {'transactions': transactions})
