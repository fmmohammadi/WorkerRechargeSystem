from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
import csv
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.urls import path
from django import forms
from django.utils import timezone

class Worker(models.Model):
    name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15, unique=True)

    def __str__(self):
        return f"{self.name} ({self.phone_number})"

class ChargeTransaction(models.Model):
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE)
    amount = models.PositiveIntegerField()
    buyer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.worker.name} - {self.amount} - {self.timestamp.strftime('%Y-%m-%d %H:%M')}"

    def get_charge_url(self):
        return "https://www.asanpardakht.ir"

    class Meta:
        ordering = ['-timestamp']

    @staticmethod
    def export_to_csv(queryset):
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="charge_transactions.csv"'
        writer = csv.writer(response)
        writer.writerow(['کارگر', 'شماره', 'مبلغ', 'تاریخ', 'خریدار'])
        for tx in queryset:
            writer.writerow([
                tx.worker.name,
                tx.worker.phone_number,
                tx.amount,
                tx.timestamp.strftime('%Y-%m-%d %H:%M'),
                tx.buyer.username if tx.buyer else '---'
            ])
        return response

class ChargeForm(forms.ModelForm):
    class Meta:
        model = ChargeTransaction
        fields = ['worker', 'amount']

class ReportFilterForm(forms.Form):
    from_date = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    to_date = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    worker = forms.ModelChoiceField(queryset=Worker.objects.all(), required=False)

@login_required
def add_charge_view(request):
    if request.method == 'POST':
        form = ChargeForm(request.POST)
        if form.is_valid():
            charge = form.save(commit=False)
            charge.buyer = request.user
            charge.save()
            return redirect(charge.get_charge_url())
    else:
        form = ChargeForm()
    return render(request, 'add_charge.html', {'form': form})

@login_required
def report_view(request):
    transactions = ChargeTransaction.objects.select_related('worker', 'buyer').all()
    form = ReportFilterForm(request.GET or None)

    if form.is_valid():
        if form.cleaned_data['from_date']:
            transactions = transactions.filter(timestamp__gte=form.cleaned_data['from_date'])
        if form.cleaned_data['to_date']:
            transactions = transactions.filter(timestamp__lte=form.cleaned_data['to_date'])
        if form.cleaned_data['worker']:
            transactions = transactions.filter(worker=form.cleaned_data['worker'])

    return render(request, 'report.html', {
        'transactions': transactions,
        'form': form
    })

@login_required
def export_transactions_csv(request):
    transactions = ChargeTransaction.objects.all()
    return ChargeTransaction.export_to_csv(transactions)

urlpatterns = [
    path('export/', export_transactions_csv, name='export_csv'),
    path('report/', report_view, name='report_view'),
    path('add/', add_charge_view, name='add_charge_view'),
]
