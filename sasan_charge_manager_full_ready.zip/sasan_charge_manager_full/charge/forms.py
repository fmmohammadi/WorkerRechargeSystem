from django import forms
from .models import ChargeTransaction, Worker

class ChargeForm(forms.ModelForm):
    class Meta:
        model = ChargeTransaction
        fields = ['worker', 'amount']

class ReportFilterForm(forms.Form):
    from_date = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    to_date = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    worker = forms.ModelChoiceField(queryset=Worker.objects.all(), required=False)
