from django.urls import path
from .views import add_charge_view, report_view, export_transactions_csv

urlpatterns = [
    path('add/', add_charge_view, name='add_charge_view'),
    path('report/', report_view, name='report_view'),
    path('export/', export_transactions_csv, name='export_csv'),
]
