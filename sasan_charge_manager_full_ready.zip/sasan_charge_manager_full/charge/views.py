from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import ChargeForm, ReportFilterForm
from .models import ChargeTransaction
from django.http import HttpResponse
import csv

@login_required
def add_charge_view(request):
    if request.method == 'POST':
        form = ChargeForm(request.POST)
        if form.is_valid():
            charge = form.save(commit=False)
            charge.buyer = request.user
            charge.save()
            return redirect(charge.get_charge_url())
    else:
        form = ChargeForm()
    return render(request, 'add_charge.html', {'form': form})

@login_required
def report_view(request):
    transactions = ChargeTransaction.objects.select_related('worker', 'buyer').all()
    form = ReportFilterForm(request.GET or None)

    if form.is_valid():
        if form.cleaned_data['from_date']:
            transactions = transactions.filter(timestamp__gte=form.cleaned_data['from_date'])
        if form.cleaned_data['to_date']:
            transactions = transactions.filter(timestamp__lte=form.cleaned_data['to_date'])
        if form.cleaned_data['worker']:
            transactions = transactions.filter(worker=form.cleaned_data['worker'])

    return render(request, 'report.html', {
        'transactions': transactions,
        'form': form
    })

@login_required
def export_transactions_csv(request):
    transactions = ChargeTransaction.objects.all()
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="charge_transactions.csv"'

    writer = csv.writer(response)
    writer.writerow(['کارگر', 'شماره', 'مبلغ', 'تاریخ', 'خریدار'])
    for tx in transactions:
        writer.writerow([
            tx.worker.name,
            tx.worker.phone_number,
            tx.amount,
            tx.timestamp.strftime('%Y-%m-%d %H:%M'),
            tx.buyer.username if tx.buyer else '---'
        ])
    return response
