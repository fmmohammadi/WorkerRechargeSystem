from django.contrib import admin
from .models import Worker, ChargeTransaction

admin.site.register(Worker)
admin.site.register(ChargeTransaction)
