from django.db import models
from django.contrib.auth.models import User

class Worker(models.Model):
    name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15, unique=True)

    def __str__(self):
        return f"{self.name} ({self.phone_number})"

class ChargeTransaction(models.Model):
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE)
    amount = models.PositiveIntegerField()
    buyer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.worker.name} - {self.amount} - {self.timestamp.strftime('%Y-%m-%d %H:%M')}"

    def get_charge_url(self):
        return "https://www.asanpardakht.ir"

    class Meta:
        ordering = ['-timestamp']
